# backend/app/routes/analysis.py
#
# Financial Analysis Router
# Provides free + premium analysis endpoints derived from existing
# transactions and account data already in the DB.
#
# FREE endpoints:
#   GET /analysis/bills          – detected recurring bills + income
#   GET /analysis/liquidity      – liquidity & solvency ratios
#
# PREMIUM endpoints (requires user.is_premium == True):
#   GET /analysis/debt           – debt management breakdown
#   GET /analysis/profitability  – profitability & growth over time
#   GET /analysis/forecast       – forward projections (3m/6m/2yr/10yr)
#
# Wiring checklist:
#   1. Include this router in your main app file (e.g. app/main.py):
#        from app.routes.analysis import router as analysis_router
#        app.include_router(analysis_router, prefix="/analysis", tags=["analysis"])
#   2. Replace every # TODO with your real ORM queries.
#   3. Add `is_premium: bool = False` column to your User model if not present.

from __future__ import annotations

from collections import defaultdict
from datetime import date, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

# ── imports aligned to backend/app/ structure ─────────────────────────────────
from app.core.security import get_current_user   # your existing auth dependency
from app.models.user import User                 # adjust model filenames as needed
from app.models.bank_account import BankAccount
from app.models.transaction import Transaction
from app.core.config import get_db               # or wherever your DB session lives
# ──────────────────────────────────────────────────────────────────────────────

router = APIRouter()

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

BILL_KEYWORDS = [
    "netflix", "spotify", "hulu", "disney", "apple", "amazon prime",
    "rent", "mortgage", "electric", "gas", "water", "internet", "comcast",
    "at&t", "verizon", "t-mobile", "insurance", "geico", "progressive",
    "allstate", "state farm", "gym", "planet fitness", "equinox",
    "adobe", "microsoft", "google", "dropbox", "icloud",
]

INCOME_KEYWORDS = [
    "payroll", "direct deposit", "salary", "wage", "ach credit",
    "venmo", "zelle", "transfer in", "deposit",
]

def _is_bill(description: str) -> bool:
    d = description.lower()
    return any(k in d for k in BILL_KEYWORDS)

def _is_income(description: str) -> bool:
    d = description.lower()
    return any(k in d for k in INCOME_KEYWORDS)

def _require_premium(user: User):
    if not getattr(user, "is_premium", False):
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail="This feature requires a Cashism Premium subscription.",
        )

# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------

class BillItem(BaseModel):
    name: str
    amount: float          # average monthly amount (absolute value)
    frequency: str         # "monthly" | "annual" | "irregular"
    category: str | None

class IncomeItem(BaseModel):
    source: str
    amount: float          # average per-period
    frequency: str

class BillsResponse(BaseModel):
    monthly_bills_total: float
    annual_bills_total: float
    stable_income_monthly: float
    surplus_deficit: float         # income - bills (positive = above water)
    bills: list[BillItem]
    income_sources: list[IncomeItem]


class LiquidityResponse(BaseModel):
    current_ratio: float | None     # liquid assets / monthly obligations
    cash_buffer_months: float | None  # how many months of bills cash covers
    total_liquid: float
    total_monthly_obligations: float
    solvency_score: int             # 0-100 composite
    solvency_label: str             # "Healthy" | "Moderate" | "At Risk"
    insights: list[str]


class DebtItem(BaseModel):
    account_name: str
    balance: float
    account_type: str
    estimated_monthly_payment: float | None

class DebtResponse(BaseModel):
    total_debt: float
    debt_to_income_ratio: float | None
    monthly_debt_payments: float
    payoff_months_estimate: int | None
    items: list[DebtItem]
    insights: list[str]


class ProfitabilityPoint(BaseModel):
    period: str            # "2025-01", "2025-02" …
    income: float
    expenses: float
    net: float
    savings_rate: float | None

class ProfitabilityResponse(BaseModel):
    avg_monthly_net: float
    avg_savings_rate: float | None
    trend: str             # "improving" | "declining" | "stable"
    periods: list[ProfitabilityPoint]
    insights: list[str]


class ForecastPoint(BaseModel):
    label: str             # "3 months", "6 months", "2 years", "10 years"
    months_out: int
    projected_balance: float
    projected_savings_accumulated: float
    scenario_low: float
    scenario_high: float

class ForecastResponse(BaseModel):
    monthly_surplus: float
    annual_surplus: float
    points: list[ForecastPoint]
    assumptions: list[str]


# ---------------------------------------------------------------------------
# FREE — Bills & Income  GET /analysis/bills
# ---------------------------------------------------------------------------

@router.get("/bills", response_model=BillsResponse)
async def get_bills(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Session = Depends(get_db),
):
    # TODO: replace with your actual query
    # Fetch last 90 days of transactions for this user
    since = date.today() - timedelta(days=90)
    transactions: list[Transaction] = (
        db.query(Transaction)
        .join(BankAccount)
        .filter(
            BankAccount.user_id == current_user.id,
            Transaction.created_at >= since,
        )
        .all()
    )

    # ── Detect bills ──────────────────────────────────────────────────────
    bill_map: dict[str, list[float]] = defaultdict(list)
    income_map: dict[str, list[float]] = defaultdict(list)

    for tx in transactions:
        amt = float(tx.amount)
        if _is_bill(tx.description) and amt < 0:
            key = tx.description.strip().title()
            bill_map[key].append(abs(amt))
        elif _is_income(tx.description) and amt > 0:
            key = tx.description.strip().title()
            income_map[key].append(amt)

    # Average per occurrence → monthly estimate (over ~3 months)
    bills: list[BillItem] = []
    monthly_bills_total = 0.0
    for name, amounts in bill_map.items():
        avg = sum(amounts) / len(amounts)
        monthly_bills_total += avg
        bills.append(BillItem(
            name=name,
            amount=round(avg, 2),
            frequency="monthly",
            category=getattr(transactions[0], "category", None),
        ))

    income_sources: list[IncomeItem] = []
    stable_income = 0.0
    for src, amounts in income_map.items():
        avg = sum(amounts) / max(len(amounts), 1)
        stable_income += avg
        income_sources.append(IncomeItem(
            source=src,
            amount=round(avg, 2),
            frequency="monthly",
        ))

    annual_bills = monthly_bills_total * 12

    return BillsResponse(
        monthly_bills_total=round(monthly_bills_total, 2),
        annual_bills_total=round(annual_bills, 2),
        stable_income_monthly=round(stable_income, 2),
        surplus_deficit=round(stable_income - monthly_bills_total, 2),
        bills=bills,
        income_sources=income_sources,
    )


# ---------------------------------------------------------------------------
# FREE — Liquidity & Solvency  GET /analysis/liquidity
# ---------------------------------------------------------------------------

@router.get("/liquidity", response_model=LiquidityResponse)
async def get_liquidity(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Session = Depends(get_db),
):
    # TODO: replace with your actual query
    accounts: list[BankAccount] = (
        db.query(BankAccount)
        .filter(BankAccount.user_id == current_user.id)
        .all()
    )

    liquid_types = {"checking", "savings", "depository"}
    total_liquid = sum(
        float(a.balance)
        for a in accounts
        if a.account_type.lower() in liquid_types and float(a.balance) > 0
    )

    # Reuse bills endpoint logic (or call internally) for monthly obligations
    # For skeleton we stub this — wire to real data
    monthly_obligations = 0.0  # TODO: sum of detected monthly bills

    current_ratio = (total_liquid / monthly_obligations) if monthly_obligations > 0 else None
    cash_buffer = (total_liquid / monthly_obligations) if monthly_obligations > 0 else None

    # Simple solvency score 0-100
    score = 50
    insights: list[str] = []
    if cash_buffer is not None:
        if cash_buffer >= 6:
            score = 90
            insights.append("Excellent — you have 6+ months of cash runway.")
        elif cash_buffer >= 3:
            score = 70
            insights.append("Solid — aim for 6 months of reserves.")
        elif cash_buffer >= 1:
            score = 45
            insights.append("Tight — consider building a 3-month emergency fund.")
        else:
            score = 20
            insights.append("At risk — liquid assets cover less than 1 month of bills.")

    if total_liquid < 1000:
        insights.append("Your liquid balance is very low. Prioritize building savings.")

    label = "Healthy" if score >= 70 else ("Moderate" if score >= 40 else "At Risk")

    return LiquidityResponse(
        current_ratio=round(current_ratio, 2) if current_ratio else None,
        cash_buffer_months=round(cash_buffer, 1) if cash_buffer else None,
        total_liquid=round(total_liquid, 2),
        total_monthly_obligations=round(monthly_obligations, 2),
        solvency_score=score,
        solvency_label=label,
        insights=insights,
    )


# ---------------------------------------------------------------------------
# PREMIUM — Debt Management  GET /analysis/debt
# ---------------------------------------------------------------------------

@router.get("/debt", response_model=DebtResponse)
async def get_debt(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Session = Depends(get_db),
):
    _require_premium(current_user)

    # TODO: replace with your actual query
    accounts: list[BankAccount] = (
        db.query(BankAccount)
        .filter(BankAccount.user_id == current_user.id)
        .all()
    )

    debt_types = {"credit", "loan", "mortgage", "credit card", "student"}
    debt_accounts = [
        a for a in accounts
        if any(d in a.account_type.lower() for d in debt_types)
        or float(a.balance) < 0
    ]

    total_debt = sum(abs(float(a.balance)) for a in debt_accounts)
    # TODO: calculate real monthly payments from transactions
    monthly_payments = 0.0
    stable_income = 0.0  # TODO: pull from bills endpoint

    dti = (monthly_payments / stable_income) if stable_income > 0 else None
    payoff_est = int(total_debt / monthly_payments) if monthly_payments > 0 else None

    insights: list[str] = []
    if dti is not None:
        if dti < 0.15:
            insights.append("Your debt-to-income ratio is healthy (under 15%).")
        elif dti < 0.36:
            insights.append("Moderate DTI. Consider accelerating high-interest debt.")
        else:
            insights.append("High DTI. Prioritize debt reduction before new obligations.")

    items = [
        DebtItem(
            account_name=a.name,
            balance=abs(float(a.balance)),
            account_type=a.account_type,
            estimated_monthly_payment=None,  # TODO
        )
        for a in debt_accounts
    ]

    return DebtResponse(
        total_debt=round(total_debt, 2),
        debt_to_income_ratio=round(dti, 3) if dti else None,
        monthly_debt_payments=round(monthly_payments, 2),
        payoff_months_estimate=payoff_est,
        items=items,
        insights=insights,
    )


# ---------------------------------------------------------------------------
# PREMIUM — Profitability & Growth  GET /analysis/profitability
# ---------------------------------------------------------------------------

@router.get("/profitability", response_model=ProfitabilityResponse)
async def get_profitability(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Session = Depends(get_db),
):
    _require_premium(current_user)

    since = date.today() - timedelta(days=365)
    # TODO: replace with your actual query
    transactions: list[Transaction] = (
        db.query(Transaction)
        .join(BankAccount)
        .filter(
            BankAccount.user_id == current_user.id,
            Transaction.created_at >= since,
        )
        .order_by(Transaction.created_at)
        .all()
    )

    # Group by YYYY-MM
    period_map: dict[str, dict] = defaultdict(lambda: {"income": 0.0, "expenses": 0.0})
    for tx in transactions:
        if tx.created_at is None:
            continue
        period = tx.created_at.strftime("%Y-%m")
        amt = float(tx.amount)
        if amt > 0:
            period_map[period]["income"] += amt
        else:
            period_map[period]["expenses"] += abs(amt)

    periods: list[ProfitabilityPoint] = []
    nets: list[float] = []
    for period in sorted(period_map.keys()):
        inc = period_map[period]["income"]
        exp = period_map[period]["expenses"]
        net = inc - exp
        savings_rate = (net / inc) if inc > 0 else None
        nets.append(net)
        periods.append(ProfitabilityPoint(
            period=period,
            income=round(inc, 2),
            expenses=round(exp, 2),
            net=round(net, 2),
            savings_rate=round(savings_rate, 3) if savings_rate else None,
        ))

    avg_net = sum(nets) / len(nets) if nets else 0.0
    avg_savings = (
        sum(p.savings_rate for p in periods if p.savings_rate is not None)
        / max(sum(1 for p in periods if p.savings_rate is not None), 1)
    )

    # Simple trend: compare first half vs second half average
    mid = len(nets) // 2
    trend = "stable"
    if mid > 0:
        first_half_avg = sum(nets[:mid]) / mid
        second_half_avg = sum(nets[mid:]) / max(len(nets[mid:]), 1)
        if second_half_avg > first_half_avg * 1.05:
            trend = "improving"
        elif second_half_avg < first_half_avg * 0.95:
            trend = "declining"

    insights: list[str] = []
    if avg_savings > 0.2:
        insights.append("Strong savings rate — you're keeping over 20% of income.")
    elif avg_savings > 0.1:
        insights.append("Moderate savings rate. Target 20%+ for long-term growth.")
    else:
        insights.append("Low savings rate. Review recurring expenses to improve margin.")

    return ProfitabilityResponse(
        avg_monthly_net=round(avg_net, 2),
        avg_savings_rate=round(avg_savings, 3),
        trend=trend,
        periods=periods,
        insights=insights,
    )


# ---------------------------------------------------------------------------
# PREMIUM — Forecast  GET /analysis/forecast
# ---------------------------------------------------------------------------

@router.get("/forecast", response_model=ForecastResponse)
async def get_forecast(
    current_user: Annotated[User, Depends(get_current_user)],
    db: Session = Depends(get_db),
):
    _require_premium(current_user)

    # TODO: replace with actual current balance + monthly surplus from real data
    accounts: list[BankAccount] = (
        db.query(BankAccount)
        .filter(BankAccount.user_id == current_user.id)
        .all()
    )

    total_balance = sum(float(a.balance) for a in accounts)
    monthly_surplus = 0.0   # TODO: pull from profitability endpoint

    # Scenario variance (±20%)
    low_factor = 0.80
    high_factor = 1.20

    horizons = [
        ("3 months", 3),
        ("6 months", 6),
        ("2 years", 24),
        ("10 years", 120),
    ]

    points: list[ForecastPoint] = []
    for label, months in horizons:
        base = total_balance + monthly_surplus * months
        points.append(ForecastPoint(
            label=label,
            months_out=months,
            projected_balance=round(base, 2),
            projected_savings_accumulated=round(monthly_surplus * months, 2),
            scenario_low=round(total_balance + monthly_surplus * months * low_factor, 2),
            scenario_high=round(total_balance + monthly_surplus * months * high_factor, 2),
        ))

    assumptions = [
        "Projection assumes current monthly surplus continues unchanged.",
        "Low scenario assumes 20% reduction in surplus (expenses increase).",
        "High scenario assumes 20% increase in surplus (income growth).",
        "Does not account for investment returns, inflation, or major life events.",
    ]

    return ForecastResponse(
        monthly_surplus=round(monthly_surplus, 2),
        annual_surplus=round(monthly_surplus * 12, 2),
        points=points,
        assumptions=assumptions,
    )